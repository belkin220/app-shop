<!DOCTYPE html>
<html>
<head>
    <title>Nuevo pedido</title>
</head>
<body>
  <p>Se ha realizado un nuevo pedido</p>
  <p>Datos del cliente que realizó el pedido:</p>
  <ul>
        <li><strong>Nombre:</strong>
        <?php echo e($user->name); ?>

    </li>
        <li><strong>E-mail:</strong>
        <?php echo e($user->email); ?>

        </li>
        <li><strong>Fecha del pedido:</strong>
        <?php echo e($cart->order_date); ?>

        </li>
        <li></li>
    </ul>  
    <hr>
    <p><strong>Detalle del pedido:</strong></p>
    <ul>
       
        <table>
          
            <thead>
                <th class="text-center">Nombre del producto</th>
                <th class="text-right">Cantidad</th>
                <th class="text-right">Subtotal</th>
                <th class="text-center">Impuestos</th>
                <th class="text-right">Total </th>
                <th class="text-right">Total Factura </th>

            </thead> 
            <?php $__currentLoopData = $cart->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr> 
                    <td><?php echo e($detail->product->name); ?></td>
                    <td class="text-right"><?php echo e($detail->quantity); ?></td>
                    <td class="text-right"><?php echo e($detail->quantity * $detail->product->price); ?></td>
                    <td class="text-center">21%</td>
                    <td class="text-right"><?php echo e($cart->total); ?></td>
                    <td colspan="4" class="text-right"><?php echo e($sum); ?></td>

                </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <hr>
    <p>
        <a href="<?php echo e(url('admin/orders/' . $cart->id )); ?>">Haz click aquí para más información sobre este pedido</a>
    </p>
    </p>
</body>
</html>