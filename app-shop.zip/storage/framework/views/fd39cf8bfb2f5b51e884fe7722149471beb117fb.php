<?php $__env->startSection('body-class','product-page'); ?>
<?php $__env->startSection('title','Editar categoria'); ?>
<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">

</div>

<div class="main main-raised">
<div class="container">
    <div class="section">
        <h2 class="title text-center">Editar categoria</h2>
        
        
        
         <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                    </div>
                     <?php endif; ?>
                     

        <form action="<?php echo e(route('admin.category.update', $category->id)); ?>" method="post" accept-charset="utf-8">
            <?php echo e(csrf_field()); ?>

            <div class="row">

            <div class="col-sm-6">
                <div class="form-group label-floating">
                    <label class="control-label">Nombre del producto </label>
                    <input type="text" class="form-control"name="name" id="name" value="<?php echo e(old('name',$category->name)); ?>">
                </div>
            </div>

        <div class="col-sm-6">
            <div class="form-group label-floating">
                    <label class="control-label">Descripción </label>
                    <input type="text" class="form-control" name="description" id="description" value="<?php echo e(old('description',$category->description)); ?>">
            </div>
        </div>
    </div>
            <button type="submit" class="btn btn-primary">Actualizar categoria</button>
            <a href="<?php echo e(route('admin.category')); ?>" role="button" class="btn btn-default">Cancelar </a>
</div>

        </form>
                
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>