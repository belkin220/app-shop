<?php $__env->startSection('body-class','product-page'); ?>
<?php $__env->startSection('title','App Shop| Panel de Control'); ?>
<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">

</div>

<div class="main main-raised">
<div class="container">
    

    <div class="section">
        <h2 class="title text-center">Panel de Usuario</h2>

        <?php if(session('notification')): ?>
            <div class="alert alert-success">
                <div class="container-fluid">
                  <div class="alert-icon">
                    <i class="material-icons">check</i>
                  </div>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true"><i class="material-icons">clear</i></span>
                  </button>
                   <?php echo e(session('notification')); ?>

                </div>
            </div>
        <?php endif; ?>
        <!-- Nav Pills -->
              <ul class="nav nav-pills nav-pills-primary" role="tablist">
            <li class="active">
                <a href="#dashboard" role="tab" data-toggle="tab">
                    <i class="material-icons">shopping_cart</i>
                    Carrito de compras
                </a>
            </li>
            <li>
                <a href="#tasks" role="tab" data-toggle="tab">
                    <i class="material-icons">list</i>
                    Historial de pedidos
                </a>
            </li>
            
        </ul>
        <!-- Listado carrito -->
        <hr>
       <?php 
       $count = auth()->user()->cart->details->count();
       ?>
        <?php switch($count):
            case ( $count = 0 ): ?>
            <span class="label label-info"><b> Tu carrito de compras está vacío.</b></span>
            <?php break; ?>;

            <?php case ( $count = 1 ): ?>
            <span class="label label-info"><b>Tienes <?php echo e($count); ?> producto en tu carrito.</b></span>
            <?php break; ?>;
            
            <?php case ( $count > 1 ): ?>
            <span class="label label-info"><b>Tienes <?php echo e($count); ?> productos en tu carrito.</b></span>
            <?php break; ?>
        <?php endswitch; ?>
        
                <table class = "table table-bordered" style="margin-top: 50px">
                    <thead>
                        <tr>
                            <th class = "text-center"> Imagen </th>
                            <th class=" text-center"> Nombre </th>
                            <th class=" text-center"> Precio </th>
                            <th class=" text-center"> Cantidad </th>
                            <th class=" text-center"> Subtotal </th>
                            <th class=" text-center"> Acciones </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = auth()->user()->cart->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="vertical-align: middle;"><img src="<?php echo e($detail->product->featured_image_url); ?>" width="50" height="50">
                             </td>
                            <td style="vertical-align: middle;text-align: left;"><a href="<?php echo e(route('customer.products.show',$detail->product->id)); ?>" title="<?php echo e($detail->product->name); ?>" target="_blank" ><?php echo e($detail->product->name); ?></a> </td>
                            <td class = "text-right" style="vertical-align: middle;"> <?php echo e($detail->product->price); ?> &euro; </td>
                            <td class = "text-center" style="vertical-align: middle"> <?php echo e($detail->quantity); ?> </td>
                            <td class = "text-center" style="vertical-align: middle"> <?php echo e($detail->quantity * $detail->product->price); ?> &euro; </td>
                           
                            <td class = "td-actions text-center" style="vertical-align: middle">
                                <form action="<?php echo e(route('cart.delete',$detail->id )); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                     <a  href="<?php echo e(route('customer.products.show',[$detail->product->id,'carrito'=>true])); ?>" role = "button" rel = "tooltip" title = "Ver producto" class = "btn btn-info btn-simple btn-xs">
                                    <i class = "fa fa-info"> </i>
                                </a>
                                <button type = "submit" rel = "tooltip" title = "Eliminar producto" class = "btn btn-danger btn-simple btn-xs">
                                    <i class = "fa fa-times"> </i>
                                </button>
                            </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="text-center col-md-6">
                <a href="<?php echo e(route('welcome')); ?>#welcome" class="btn btn-primary btn-round">
    <i class="material-icons">shopping_basket</i> Seguir comprando
</a>
</div>
<div class="text-right">
    <form action="<?php echo e(route('cart.update')); ?>" method="post" accept-charset="utf-8">
        <?php echo e(csrf_field()); ?>

        <button class="btn btn-primary btn-round">
    <i class="material-icons">done</i> Realizar pedido
</button>

    </form>
</div>

        



















        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>