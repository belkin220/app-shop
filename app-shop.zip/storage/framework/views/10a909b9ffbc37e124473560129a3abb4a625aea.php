<?php $__env->startSection('body-class','product-page'); ?>
<?php $__env->startSection('title','Bienvenido a App Shop|Crear producto'); ?>
<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">
    
</div>
<div class="main main-raised">
<div class="container">
    <div class="section">
        <h2 class="title text-center">Registrar producto</h2>

        <?php if(session('notification')): ?>
        <div class="alert alert-success" style="margin-top: 25px">
                          <div class="container-fluid">
                            <div class="alert-icon">
                              <i class="material-icons">check</i>
                            </div>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true"><i class="material-icons">clear</i></span>
                            </button>
                             <?php echo e(session('notification')); ?>

                           </div>
                      </div>
                      <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin.products.store')); ?>" method="post" accept-charset="utf-8">
            <?php echo e(csrf_field()); ?>

            <div class="row">

            <div class="col-sm-6">
                <div class="form-group label-floating">
                    <label class="control-label">Nombre del producto </label>
                    <input type="text" class="form-control"name="name" id="name" autofocus value=<?php echo e(old('name')); ?>>
                </div>
            </div>

            <div class="col-sm-6">
                 <div class="form-group label-floating">
                    <label class="control-label">Precio del producto </label>
                    <input type="text" class="form-control"name="price" id="price" value=<?php echo e(old('price')); ?>>
                </div>
            </div>
            <div class="col-sm-6">
            <div class="form-group label-floating">
                    <label class="control-label">Descripción </label>
                    <input type="text" class="form-control"name="description" id="description" value=<?php echo e(old('description')); ?>>
            </div>
        </div>

        <div class="col-sm-4">
           <div class="form-group label-floating">
                    <label class="control-label">Categoria </label>
                    <select class="form-control"name="category_id" id="category_id"> 
                        <option value="0" disable selected>Seleccione una opción</option>
                         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value=<?php echo e($category->id); ?>><?php echo e($category->name); ?></option> 
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                   
                </div>
            </div>
             <div class="col-sm-2">
                 <div class="form-group">
                    <a href="<?php echo e(url('admin/categories/create',array('redirect'=>true))); ?>" class="btn btn-primary btn-round btn-sm">
                    <i class="material-icons">add</i> Nueva categoria
                    </a>
                </div>
            </div>
        </div>
   
            <textarea class="form-control" placeholder="Descripción detallada del producto" rows="5" name="long_description"><?php echo e(old('long_description')); ?></textarea>
            <button class="btn btn-primary">Registrar producto</button>
            <a href="<?php echo e(route('admin.products')); ?>" role="button" class="btn btn-default">Cancelar </a>
        </div>
    </form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>