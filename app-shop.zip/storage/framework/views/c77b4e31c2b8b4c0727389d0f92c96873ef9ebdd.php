<?php $__env->startSection('body-class','product-page'); ?>
<?php $__env->startSection('title','Imágenes de productos'); ?>
<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">
</div>
<div class="main main-raised">
    <div class="container">
        <div class="section text-center">
            <h2 class="title">Imágenes del producto "<?php echo e($product->name); ?>"</h2>
            <form action="<?php echo e(route('admin.products.images.store',$product->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="col-md-4">
               <input type="file" name="photo" class="btn btn-primary btn-round"  required></div>
               <button type="submit" class="btn btn-primary btn-round">subir imagaen</button>
               <a href="<?php echo e(route('admin.products')); ?>" class="btn btn-default btn-round">Volver</a>
</form>
<hr>
       <div class="row" style="margin-top: 30px"> 
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                  <img src="<?php echo e($image->url); ?>" width="250" height="250" alt="Producto sin imagen">
                  <div class="caption">
                    <h3><?php echo e($image->id); ?></h3>
                    <p>...</p>

                    <form action="<?php echo e(route('admin.products.images.delete',$image->id)); ?>" method="POST" >
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                     
                    <p><button type="submit" class="btn btn-primary" role="button">Eliminar</button>
                      <?php if($image->featured): ?>
                      <button type="button" class="btn btn-info btn-fab btn-fab-mini btn-round" rel="tooltip" title="Imagen destacada"><i class="material-icons">favorite</i></a></p>
                      <?php else: ?>
                      <a href="<?php echo e(route('admin.products.images.select', [$product->id,$image->id])); ?>" class="btn btn-success btn-fab btn-fab-mini btn-round" rel="tooltip" title="Destacar esta imagen"><i class="material-icons">favorite</i></a></p>
                      <?php endif; ?>

                    </form>
                  </div>
                </div>
              </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($images->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>