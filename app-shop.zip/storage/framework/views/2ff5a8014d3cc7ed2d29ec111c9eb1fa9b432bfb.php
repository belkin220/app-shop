<?php $__env->startSection('body-class','prduct-page'); ?>
<?php $__env->startSection('title','Bienvenido a App Shop'); ?>
<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">
    
</div>
<div class="main main-raised">
<div class="container">
    <div class="section">
        <h2 class="title text-center">Registrar categoria</h2>

      <?php if(session('notification')): ?>
                      <div class="alert alert-success" style="margin-top: 25px">
                          <div class="container-fluid">
                            <div class="alert-icon">
                              <i class="material-icons">check</i>
                            </div>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true"><i class="material-icons">clear</i></span>
                            </button>
                             <?php echo e(session('notification')); ?>

                           </div>
                      </div>
                  <?php endif; ?>
        

        <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(url('admin/categories/')); ?>" method="post" accept-charset="utf-8">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
            <div class="row">
            <div class="col-sm-6">
                <div class="form-group label-floating">
                    <label class="control-label">Nombre categoria</label>
                    <input type="text" class="form-control" name="name" id="name" autofocus value=<?php echo e(old('name')); ?>>
                </div>
            </div>

           
            <div class="col-sm-6">
            <div class="form-group label-floating">
                    <label class="control-label">Descripción </label>
                    <input type="text" class="form-control"name="description" id="description" value=<?php echo e(old('description')); ?>>
            </div>
        </div>
    </div>
            <button type="submit" class="btn btn-primary">Registrar categoria</button>
            <a href="<?php echo e(route('admin.category')); ?>" role="button" class="btn btn-default">Cancelar </a>
        </div>
    </form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>