<?php $__env->startSection('body-class','landing-page'); ?>

<?php $__env->startSection('title','Bienvenido a ' . config('app.name')); ?>

<?php $__env->startSection('styles'); ?>
    <style >
    .team .row .col-md-4 {margin-bottom: 5em;}
    .team .row {
      display: -webkit-box;
      display: -webkit-flex;
      display: -ms-flexbox;
      display:         flex;
      flex-wrap: wrap;
    }
   .team .row > [class*='col-'] {
      display: flex;
      flex-direction: column;
    }

    .tt-query {
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
     -moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}

.tt-hint {
  color: #999
}

.tt-menu {    /* used to be tt-dropdown-menu in older versions */
  width: 200px;
  margin-top: 4px;
  padding: 4px 0;
  background-color: #fff;
  border: 1px solid #ccc;
  border: 1px solid rgba(0, 0, 0, 0.2);
  -webkit-border-radius: 4px;
     -moz-border-radius: 4px;
          border-radius: 4px;
  -webkit-box-shadow: 0 5px 10px rgba(0,0,0,.2);
     -moz-box-shadow: 0 5px 10px rgba(0,0,0,.2);
          box-shadow: 0 5px 10px rgba(0,0,0,.2);
}

.tt-suggestion {
  padding: 3px 20px;
  line-height: 24px;
}

.tt-suggestion.tt-cursor,.tt-suggestion:hover {
  color: #fff;
  background-color: #0097cf;

}

.tt-suggestion p {
  margin: 0;
}

  
        </style>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1 class="title">Bienvenido a <?php echo e(config('app.name')); ?>.</h1>
            <h4>Realiza pedidos en línea y te contactaremos para coordinar la entrega.</h4>
            <br />
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class="btn btn-danger btn-raised btn-lg">
                <i class="fa fa-play"></i> Cómo funciona
            </a>
        </div>
    </div>
</div>
</div>

<div class="main main-raised">
<div class="container">
    <div class="section text-center section-landing">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <h2 class="title" id="shop">Por qué <?php echo e(config('app.name')); ?></h2>
                <h5 class="description">Puedes revisar nuestra relación completa de categoryos, comparar precios y realizar tus pedidos cuando estés seguro.</h5>
            </div>
        </div>

        <div class="features">
            <div class="row">
                <div class="col-md-4">
                    <div class="info">
                        <div class="icon icon-primary">
                            <i class="material-icons">chat</i>
                        </div>
                        <h4 class="info-title">Atendemos tus dudas</h4>
                        <p>Atendemos rápidamente cualquier consulta que tengas via chat. No estás solo, sino que siempre estamos atentos a tus inquietudes.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info">
                        <div class="icon icon-success">
                            <i class="material-icons">verified_user</i>
                        </div>
                        <h4 class="info-title">Pago seguro</h4>
                        <p>Todo pedido que realices será confirmado a través de llamada. Podrás pagar también contra reembolso</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info">
                        <div class="icon icon-danger">
                            <i class="material-icons">fingerprint</i>
                        </div>
                        <h4 class="info-title">Información privada</h4>
                        <p>Los pedidos que realices sólo loa conocerás tú a través del panel de usuario.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section text-center" style="margin-top: -150px">
        <h2 class="title" id="welcome">Visita nuestras categorias</h2>
   
 <div class="section text-center" style="margin-top: -75px">
        <form class="form-inline" method="get" action="<?php echo e(url('/search')); ?>">
            <input type="text" name="query" id="search"  value="" placeholder="Buscar un producto..." autocomplete="off" class="form-control" >
            <button class="btn btn-primary btn-just-icon" type="submit">
                <i class="material-icons">search</i>
            </button>
          
        </form>
  </div> 
</div>
  
<div class="team" style="margin-top: -50px">
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="team-player">
                        <!-- Se ha definido un accesor en el modelo-->
                        <img src="<?php echo e($category->featured_image_url); ?>" alt="Thumbnail Image" class="img-raised img-circle">
                        <h4 class="title">
                            <a href="<?php echo e(route('category.show', $category->id)); ?>"><?php echo e($category->name); ?></a>
                            <br/>
                            <small class="text-muted"><?php echo e($category->name); ?></small>
                        </h4>
                        <p class="description"><?php echo e($category->description); ?></p>
                       
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
      </div>
        <div class="section landing-section">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <h2 class="text-center title">¿Aún no te has registrado?</h2>
                <h4 class="text-center description">Regístrate ingresando tus datos básicos y podrás realizar tus pedidos a través de nuestro carrito de compras.</h4>
                <form class="contact-form">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group label-floating">
                                <label class="control-label">Nombre</label>
                                <input type="email" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group label-floating">
                                <label class="control-label">Correo electrónico</label>
                                <input type="email" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="form-group label-floating">
                        <label class="control-label">Tu mensaje</label>
                        <textarea class="form-control" rows="4"></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-md-offset-4 text-center">
                            <button class="btn btn-primary btn-raised">
                                Enviar consulta
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/corejs-typeahead/1.2.1/typeahead.bundle.js"></script>

 
<script>
   
   var products = new Bloodhound({
  datumTokenizer: Bloodhound.tokenizers.whitespace,
  queryTokenizer: Bloodhound.tokenizers.whitespace,
  // `states` is an array of state names defined in "The Basics"
  prefetch: "<?php echo e(url('products/json')); ?>"
  });


    $('#search').typeahead({
        hint: true,
        highlight: true,
        minLenght: 1
    },
    {
        name: 'products',
        source: products
    })

   

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>