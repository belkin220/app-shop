<footer class="footer">
<div class="container">
    <nav class="pull-left">
        <ul>
            <li>
                <a href="http://www.creative-tim.com">
                    ¿Necesitas un proyecto para tu empresa?
                </a>
            </li>
            <li>
                <a href="http://presentation.creative-tim.com">
                   Asesorìa personalizada
                </a>
            </li>
            <li>
                <a href="http://blog.creative-tim.com">
                   Blog
                </a>
            </li>
            <li>
                <a href="http://www.creative-tim.com/license">
                    Contacto
                </a>
            </li>
        </ul>
    </nav>
    <div class="copyright pull-right">
        &copy; 2016, made with <i class="fa fa-heart heart"></i> by Creative Tim
    </div>
</div>
</footer>