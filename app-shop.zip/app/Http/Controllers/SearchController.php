<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class SearchController extends Controller
{
    public function show(Request $request)
    {
    	$query = $request->input('query');
    	$products = Product::where('name','like', "%$query%")->paginate(10);

    	if($products->count() == 1) {

    		$id = $products->first()->id;

    		return redirect("/products/$id");
    	}
    	return view('search.show',compact('products','query'));
    }

    public function data()
    {
    	//pluck devuelve solo el campo name, devuelve una coleccion con solo el name del producto.
    	
    	$products = Product::pluck('name');
    	return $products;
    }


}
